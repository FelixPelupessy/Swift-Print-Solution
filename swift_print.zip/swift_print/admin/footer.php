<footer class="sticky-footer bg-white" style="position: fixed; bottom:0; width:100%">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; SWITFT PRINT <?= date('Y'); ?></span>
        </div>
    </div>
</footer>